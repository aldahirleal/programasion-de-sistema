#include "foo.h"
#include <iostream>
using namespace std;
void foo(){
	cout << "hola mi nombre es [Sebastian]" << "\n";
}
