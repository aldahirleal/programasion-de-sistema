#ifndef F00_H__
#define F00_H__

void foo();

#endif
