#include "foo.h"
#include <iostream>
using namespace std;
int main(){
	cout << "Esta es una prueba de biblioteca compartida hecha por [Sebastian!!]" << "\n";
	foo();
	return 0;

}
