#include "foo.h"
#include <iostream>
using namespace std;
void foo(){
	cout << "Hola mi nombre es [Sebastian!!]." << "\n";
}
