#include <stdio.h>
#include "foo.h"

int main(void){
	printf("Esta es una prueba de biblioteca compartida hecho por Sebastian");
	foo();
	return 0;

}
