#include <stdio.h>
void foo(void){
	printf("\n Hola mi nombre es: Sebastian \n");
}
